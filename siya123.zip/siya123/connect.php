<?php
$con=new mysqli('localhost','root','',
'project1');

if(!$con){
    die(mysqli_error($con));


}


?>