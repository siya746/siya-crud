<?php
include 'connect.php';
if(isset($_POST['submit'])){
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$password=$_POST['password'];

$sql="insert into p1(name,email,phone,password)
values('$name','$email','$mobile','$password')";
$result=mysqli_query($con,$sql);
if($result){
  // echo "data inserted successfully";
  header("location:display.php");
}else{
  die(mysqli_error($con));
}

}
  ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <title>project</title>
  </head>
  <body>
    <div class="container my-5">
    <form method="post">
     <div class="form-group">
      <label>name</label>
      <input type="text" class="form-control"
     placeholder="Enter your name"
     name="name" autocomplete="off" >
</div>
<div class="form-group">
      <label>email</label>
      <input type="Email" class="form-control"
      placeholder="Enter your email" 
      name="email" autocomplete="off" >
</div>
<div class="form-group">
      <label>mobile</label>
      <input type="text" class="form-control"
      placeholder="Enter your mobile number" 
      name="mobile" autocomplete="off" >
</div>
<div class="form-group">
      <label>password</label>
      <input type="text" class="form-control"
      placeholder="Enter your password" 
      name="password">
</div>

  <input type="submit" value="update" name="submit" class="btn btn-primary">
</form>
<div>

</div>
  </body>
</html>  
